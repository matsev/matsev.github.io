package com.jayway.application.aspects;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.DeclareError;
import org.aspectj.lang.annotation.Pointcut;

/**
 * The aspect that is responsible for architecture enforcement. In this case, it is a three layer architecture with a
 * GUI layer, a Service layer and a DAO layer.
 * 
 * The architectural rules that are enforced are:
 * <ul>
 * <li>The GUI layer must not access the DAO layer</li>
 * <li>The Service layer must not access the GUI layer</li>
 * <li>The DAO layer must not access the Service layer</li>
 * <li>The DAO layer must not access the GUI layer</li>
 * </ul>
 */
@Aspect
public class ArchitecturalEnforcement {

    /**
     * Pointcut for finding join points inside the GUI layer
     */
    @Pointcut("within(*..*gui..*)")
    public void withinGui() {}

    /**
     * Pointcut for finding join points inside the Service layer
     */
    @Pointcut("within(*..service..*)")
    public void withinService() {}

    /**
     * Pointcut for finding join points inside the DAO layer
     */
    @Pointcut("within(*..*.dao..*)")
    public void withinDao() {}


    /**
     * Pointcut for finding method calls to the GUI layer
     */
    @Pointcut("call(* *..*.gui..*(..))")
    public void callGui(){}

    /**
     * Pointcut for finding method calls to the Service layer
     */
    @Pointcut("call(* *..*.service..*(..))")
    public void callService(){}

    /**
     * Pointcut for finding method calls to the DAO layer
     */
    @Pointcut("call(* *..*.dao..*(..))")
    public void callDao(){}


    /**
     * Advice that defines an error when a GUI method calls a method in the DAO layer
     */
    @DeclareError("withinGui() && callDao()")
    @SuppressWarnings("unused")
    private static final String GUI_MUST_NOT_USE_DAO = "GUI must not access DAO";

    /**
     * Advice that defines an error when a Service method calls a method in the GUI layer
     */
    @DeclareError("withinService() && callGui()")
    @SuppressWarnings("unused")
    private static final String SERVICE_MUST_NOT_USE_GUI = "Service must not access GUI";

    /**
     * Advice that defines an error when a DAO method calls a method in the Service layer
     */
    @DeclareError("withinDao() && callService()")
    @SuppressWarnings("unused")
    private static final String DAO_MUST_NOT_USE_SERVICE = "DAO must not access Service";

    /**
     * Advice that defines an error when a DAO method calls a method in the GUI layer
     */
    @DeclareError("withinDao() && callGui()")
    @SuppressWarnings("unused")
    private static final String DAO_MUST_NOT_USE_GUI = "DAO must not access GUI";
}
