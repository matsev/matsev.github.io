package com.jayway.application.dao;

import com.jayway.application.gui.SomeGui;
import com.jayway.application.service.SomeService;

/**
 * Bad DAO implementation that violates the architectural rules because it calls a method in the GUI layer as well as
 * and a method in service layer
 */
public class BadDaoImpl implements SomeDao {

    private SomeGui someGui;
    private SomeService someService;

    @Override
    public Object find() {
        // the dao should not call the GUI...
        someGui.render();

        // ...not should it call the service
        someService.service();

        // lookup stuff in the database
        return new Object();
    }
}