package com.jayway.application.gui;

import com.jayway.application.dao.SomeDao;
import com.jayway.application.service.SomeService;

/**
 * Bad GUI implementation that violates the architectural rules because it calls a method in the DAO layer
 */
public class BadGuiImpl implements SomeGui {

    private SomeService someService;
    private SomeDao someDao;

    @Override
    public void render() {
        // it is ok to call the service...
        someService.service();

        // ... but it is not ok to call the DAO directly
        someDao.find();

        // Render GUI
    }
}