package com.jayway.application.service;

/**
 * Simplistic service interface
 */
public interface SomeService {

    /**
     * Executes some service
     */
    void service();
}
