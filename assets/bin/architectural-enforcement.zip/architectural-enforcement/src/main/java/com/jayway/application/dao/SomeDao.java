package com.jayway.application.dao;

/**
 * Simplistic DAO interface
 */
public interface SomeDao {

    /**
     * Finds something in the DAO
     * @return some data
     */
    public Object find();
}
