package com.jayway.application.service;

import com.jayway.application.dao.SomeDao;

/**
 * Good service that only uses the DAO layer
 */
public class GoodServiceImpl implements SomeService {

    private SomeDao someDao;

    @Override
    public void service() {
        // the service is allowed to call the DAO
        someDao.find();

        // do service stuff
    }
}
