package com.jayway.application.gui;

import com.jayway.application.dao.SomeDao;

/**
 * Another bad GUI implementation that violates the architectural rule
 * because it has references to the DAO layer.
 * However, these errors will remain undetected by AspectJ.
 */
public class AnotherBadGuiImpl implements SomeGui {

    /** Unused DAO reference */
    private SomeDao someDao;

    /**
     * Setter method that for some obscure reason adds a DAO to the GUI
     * @param someDao A DAO reference that is not found by the pointcut
     */
    public void setDao(SomeDao someDao) {
        this.someDao = someDao;
    }

    @Override
    public void render() {
        // valid gui rendering that does not use the dao reference
    }
}
