package com.jayway.application.dao;

/**
 * Good DAO implementation that only looks up stuff in the database
 */
public class GoodDaoImpl implements SomeDao {

    @Override
    public Object find() {
        // the DAO does not call neither the GUI nor the Service

        // lookup stuff in the database
        return new Object();
    }
}
