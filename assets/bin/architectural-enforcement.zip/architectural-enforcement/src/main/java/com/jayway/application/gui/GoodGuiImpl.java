package com.jayway.application.gui;

import com.jayway.application.service.SomeService;

/**
 * Good GUI implementation that only calls the service layer
 */
public class GoodGuiImpl implements SomeGui {

    private SomeService someService;

    @Override
    public void render() {
        // the GUI is allowed to use the service
        someService.service();
        
        // Render GUI
    }
}
