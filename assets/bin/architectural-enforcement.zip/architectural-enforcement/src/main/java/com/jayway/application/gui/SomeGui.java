package com.jayway.application.gui;

/**
 * Simplistic GUI interface
 */
public interface SomeGui {

    /**
     * Renders the GUI
     */
    void render();
}
