package com.jayway.application.service;

import com.jayway.application.dao.SomeDao;
import com.jayway.application.gui.SomeGui;

/**
 * Bad service implementation that violates the architectural rules because it calls the GUI layer 
 */
public class BadServiceImpl implements SomeService {

    private SomeDao someDao;
    private SomeGui someGui;

    @Override
    public void service() {
        // it is ok for the service to call the DAO...
        someDao.find();

        // ... but it should not call the GUI
        someGui.render();

        // do service stuff
    }
}