package example;

import javax.microedition.rms.InvalidRecordIDException;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;

/**
 * Example class for data persistence with aid of {@code RecordStore}.
 */
public class PersistentData {

	/** Data cache */
	private byte[] dataCache;

	/** Record store name */
	static final String RECORD_STORE_NAME = "persistent_data";

	/** Record store id */
	static final int RECORD_ID = 1;

	/**
	 * Gets the cached data.
	 * 
	 * @return A {@code byte[]} with the cached data.
	 */
	public byte[] getData() {
		return dataCache;
	}

	/**
	 * Writes the data to the cache.
	 * 
	 * @param data
	 *            A {@code byte[]} with the data to be cached.
	 */
	public void setData(byte[] data) {
		this.dataCache = data;
	}

	/**
	 * Reads the data from {@code RecordStore} to the cache.
	 */
	public void readDataFromRecordStore() {
		RecordStore rs = null;
		try {
			rs = RecordStore.openRecordStore(RECORD_STORE_NAME, true);
			if (rs.getNumRecords() > 0) {
				dataCache = rs.getRecord(RECORD_ID);
			}
		} catch (RecordStoreException recordStoreException) {
			// TODO Handle exception
		} finally {
			if (rs != null) {
				try {
					rs.closeRecordStore();
				} catch (RecordStoreException recordStoreException) {
					// Ignore
				}
			}
		}
	}

	/**
	 * Persists the data in the cache to the {@code RecordStore}.
	 */
	public void writeDataToRecordStore() {
		RecordStore rs = null;
		try {
			rs = RecordStore.openRecordStore(RECORD_STORE_NAME, true);
			try {
				rs.setRecord(RECORD_ID, dataCache, 0, dataCache.length);
			} catch (InvalidRecordIDException invalidRecordIDException) {
				rs.addRecord(dataCache, 0, dataCache.length);	
			}
		} catch (RecordStoreException rse) {
			// TODO Handle exception
		} finally {
			if (rs != null) {
				try {
					rs.closeRecordStore();
				} catch (RecordStoreException e) {
					// Ignore
				}
			}
		}
	}
}
