package example;

import static example.PersistentData.RECORD_ID;
import static example.PersistentData.RECORD_STORE_NAME;
import static org.easymock.EasyMock.aryEq;
import static org.easymock.EasyMock.eq;
import static org.easymock.EasyMock.expect;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertNull;
import static org.powermock.api.easymock.PowerMock.createMock;
import static org.powermock.api.easymock.PowerMock.expectLastCall;
import static org.powermock.api.easymock.PowerMock.mockStatic;
import static org.powermock.api.easymock.PowerMock.replay;
import static org.powermock.api.easymock.PowerMock.verify;

import javax.microedition.rms.InvalidRecordIDException;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor("javax.microedition.rms.RecordStore")
@PrepareForTest( { PinCode.class, RecordStore.class })
public class PersistentDataTest {

	PersistentData persitentData;
	RecordStore recordStoreMock;
	byte[] data;

	@Before
	public void setUp() throws Exception {
		mockStatic(RecordStore.class);
		recordStoreMock = createMock(RecordStore.class);
		persitentData = new PersistentData();
		data = new byte[] { 0x00, 0x01, 0x02 };
	}

	@After
	public void tearDown() throws Exception {
		persitentData = null;
		recordStoreMock = null;
	}

	@Test
	public void testGetSetData() {
		persitentData.setData(data);
		assertArrayEquals(data, persitentData.getData());
	}
	
	@Test
	public void testReadDataFromRecordStoreToCache() throws RecordStoreException {
		// Record behavior
		expect(RecordStore.openRecordStore(RECORD_STORE_NAME, true)).andReturn(
				recordStoreMock);
		expect(recordStoreMock.getNumRecords()).andReturn(1);
		expect(recordStoreMock.getRecord(RECORD_ID)).andReturn(data);
		recordStoreMock.closeRecordStore();

		// Replay behavior
		replay(recordStoreMock, RecordStore.class);

		// Execute test
		persitentData.readDataFromRecordStore();

		// Verify result
		assertArrayEquals(data, persitentData.getData());
		verify(recordStoreMock, RecordStore.class);
	}

	@Test
	public void testReadDataFromEmptyRecordStoreToCache() throws RecordStoreException {
		// Record behavior
		expect(RecordStore.openRecordStore(RECORD_STORE_NAME, true)).andReturn(
				recordStoreMock);
		expect(recordStoreMock.getNumRecords()).andReturn(0);
		recordStoreMock.closeRecordStore();

		// Replay behavior
		replay(recordStoreMock, RecordStore.class);

		// Execute test
		persitentData.readDataFromRecordStore();

		// Verify result
		assertNull(persitentData.getData());
		verify(recordStoreMock, RecordStore.class);
	}

	@Test
	public void testWriteDataFromCacheToRecordStore() throws RecordStoreException {
		// Record behavior
		expect(RecordStore.openRecordStore(RECORD_STORE_NAME, true)).andReturn(
				recordStoreMock);
		recordStoreMock.setRecord(eq(RECORD_ID), aryEq(data), eq(0), eq(data.length));
		recordStoreMock.closeRecordStore();

		// Replay behavior
		replay(recordStoreMock, RecordStore.class);

		// Execute test
		persitentData.setData(data);
		persitentData.writeDataToRecordStore();

		// Verify result
		verify(recordStoreMock, RecordStore.class);
	}
	
	@Test
	public void testFirstTimeWriteDataFromCacheToRecordStore() throws RecordStoreException {
		// Record behavior
		expect(RecordStore.openRecordStore(RECORD_STORE_NAME, true)).andReturn(
				recordStoreMock);
		recordStoreMock.setRecord(eq(RECORD_ID), aryEq(data), eq(0), eq(data.length));
		expectLastCall().andThrow(new InvalidRecordIDException());
		expect(recordStoreMock.addRecord(aryEq(data), eq(0), eq(data.length))).andReturn(RECORD_ID);
		recordStoreMock.closeRecordStore();

		// Replay behavior
		replay(recordStoreMock, RecordStore.class);

		// Execute test
		persitentData.setData(data);
		persitentData.writeDataToRecordStore();

		// Verify result
		verify(recordStoreMock, RecordStore.class);
	}

}
